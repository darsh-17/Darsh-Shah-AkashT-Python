from django.urls import path
from . import views

urlpatterns = [
    path('',views.home,name="Home"),
    path('About',views.about,name="About Us"),
    path('Contact',views.contact,name="Contact Us"),
    path('Register',views.register,name="Register"),

]
