from django.shortcuts import render

# Create your views here.
def home(request):
    return render(request,"home.html")
def calc(request):
    return render(request,"calc.html")
def formprocess(request):
    a=int(request.POST["number1"])
    b=int(request.POST["number2"])
    c=a+b
    return render(request,"ans.html",{"ans":c})