from django.shortcuts import render


def homeview(request):
    return render(request, "home.html")


def aboutview(request):
    return render(request, "about.html")


def contactview(request):
    return render(request, "contact.html")


def signupview(request):
    return render(request, "signup.html")


def registerview(request):
    return render(request, "register.html")


def process(request):
    a = request.POST["firstname"]
    b = request.POST["lastname"]
    h=request.POST["gender"]
    c = request.POST["dob"]
    d = request.POST["email"]
    e = request.POST["pass"]
    f = request.POST["state"]
    g = request.POST["district"]
    return render(request, "ans.html", {"firstname": a, "lastname": b, "dob": c, "email": d, "pass": e,
                    "state": f,"district":g,"gender":h})

