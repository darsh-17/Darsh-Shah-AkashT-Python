from django.urls import path
from . import views

urlpatterns = [
    path("",views.homeview,name="Home"),
    path("About",views.aboutview,name="About"),
    path("Contact",views.contactview,name="Contact"),
    path("SignUp",views.signupview,name="Signup"),
    path("Register",views.registerview,name="Register"),
    path("formprocess",views.process,name="Process")


]
